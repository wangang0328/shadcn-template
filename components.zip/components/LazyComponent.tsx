import React from 'react'

const LazyComponent: React.FC<{ children: React.LazyExoticComponent<() => JSX.Element> }> = (props) => (
  <React.Suspense fallback={<>loading...</>}>
    <props.children />
  </React.Suspense>
)

export default LazyComponent
