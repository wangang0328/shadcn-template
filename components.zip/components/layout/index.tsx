import { SidebarInset, useSidebar } from '@src/components/ui/sidebar'
import { AppSidebar } from './SideBar'
import Header from './header'

const Layout = ({ children }: { children: React.ReactNode }) => {
  const { open } = useSidebar()
  const width = open ? 'calc(100% - 256px)' : '100%'
  return (
    <>
      {/* 侧边栏 */}
      <AppSidebar />
      <SidebarInset style={{ width, overflow: 'hidden' }}>
        {/* 头部 */}
        <Header />
        {/* 内容部分 */}
        <div className="flex flex-none flex-col gap-4 p-4 overflow-auto" style={{ height: 'calc(100vh - 64px)' }}>
          {children}
        </div>
      </SidebarInset>
    </>
  )
}

export default Layout
