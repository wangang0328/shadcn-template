import {
  Breadcrumb as AppBreadcrumb,
  BreadcrumbItem,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator
} from '@src/components/ui/breadcrumb'
import { useMemo } from 'react'
import { NavLink, useLocation } from 'react-router-dom'
import { menuList, type IMenuItem } from '../constants'

type IBreadcrumbItem = Pick<IMenuItem, 'path' | 'title'>

// 固定有的面包屑条目
const yqBreadcrumbItem = { title: '17TRACK', path: '/dashboard' }

const getPathByPathname = (curKey: string, data: any) => {
  // 结果
  let result: IBreadcrumbItem[] = []

  const traverse = (curKey: string, path: IBreadcrumbItem[], data: IMenuItem[]) => {
    // 树为空时，不执行函数
    if (data.length === 0) {
      return
    }

    for (let item of data) {
      // 有子路由 用子路由的路径
      const key = item.children?.[0]?.path ?? item.path
      path.push({ title: item.title, path: key })
      if (item.path === curKey) {
        // 找到
        result = JSON.parse(JSON.stringify(path))
        return
      }

      const children = Array.isArray(item.children) ? item.children : []
      // 递归遍历子数组内容
      traverse(curKey, path, children)
      // 没有找到，pop掉
      path.pop()
    }
  }
  traverse(curKey, [yqBreadcrumbItem], data)
  // 返回找到的树节点路径
  return result
}

const Breadcrumb = () => {
  const { pathname } = useLocation()
  const list = useMemo(() => getPathByPathname(pathname, menuList), [pathname])
  const lenNo = list.length - 1

  return (
    <AppBreadcrumb>
      <BreadcrumbList>
        {list.map(({ path, title }, index) => (
          <>
            <BreadcrumbItem key={path} className="hidden md:block">
              {lenNo === index ? <BreadcrumbPage>{title}</BreadcrumbPage> : <NavLink to={path}>{title}</NavLink>}
            </BreadcrumbItem>
            {lenNo !== index && <BreadcrumbSeparator className="hidden md:block" />}
          </>
        ))}
      </BreadcrumbList>
    </AppBreadcrumb>
  )
}

export default Breadcrumb
