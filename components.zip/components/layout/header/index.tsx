import { Button } from '@components/ui/button'
import Image from '@src/components/image'
import { Separator } from '@src/components/ui/separator'
import { SidebarTrigger } from '@src/components/ui/sidebar'
import { Bell, CodeXml, ListTodo } from 'lucide-react'
import Breadcrumb from './Breadcrumb'

const Header = () => (
  <div className="relative h-16">
    <header className="flex h-16 justify-between items-center border-b">
      <div className="flex h-full shrink-0 items-center gap-2 px-4">
        <SidebarTrigger className="ml-1" />
        <Separator orientation="vertical" className="mr-2" style={{ height: '1rem' }} />
        <Breadcrumb />
      </div>
      <div className="flex gap-4 pr-4">
        <Button>
          <CodeXml />
          <>API Docs</>
        </Button>
        <Button variant="outline" size="icon">
          <ListTodo />
        </Button>
        <Button variant="outline" size="icon">
          <Bell />
        </Button>
        <Image
          width={40}
          height={40}
          radius="full"
          src="https://res.17track.net/asset/imgs-enum/avatar/120x120/10001.png?v=06703096f6"
        />
      </div>
    </header>
  </div>
)

export default Header
