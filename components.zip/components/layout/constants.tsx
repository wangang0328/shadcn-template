import { LucideProps, Mail, PackageSearch, PlaneTakeoff, ReceiptText, Settings2, SquareTerminal } from 'lucide-react'
import { ForwardRefExoticComponent, RefAttributes } from 'react'

export interface IMenuItem {
  title: string
  path: string
  icon?: ForwardRefExoticComponent<Omit<LucideProps, 'ref'> & RefAttributes<SVGSVGElement>>
  children?: IMenuItem[]
}

/**
 * 菜单列表数据，只支持二级目录
 */
export const menuList: IMenuItem[] = [
  {
    title: 'Dashboard',
    path: '/dashboard',
    icon: SquareTerminal
  },
  {
    title: 'Tracking',
    path: '/tracking',
    icon: PackageSearch
  },
  {
    title: '空运',
    path: '/airline',
    icon: PlaneTakeoff
  },
  {
    title: 'Notification',
    path: '/notification',
    icon: Mail,
    children: [
      {
        title: '通知自己',
        path: '/notification/own'
      },
      {
        title: '通知用户',
        path: '/notification/consumer'
      },
      {
        title: '通知历史',
        path: '/notification/history'
      }
    ]
  },
  {
    title: 'Billing',
    path: '/invoice',
    icon: ReceiptText
  },
  {
    title: 'Settings',
    path: '/settings',
    icon: Settings2
  }
]
