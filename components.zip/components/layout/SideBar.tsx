import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@src/components/ui/collapsible'
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem
} from '@src/components/ui/sidebar'
import { startsWith } from 'lodash-es'
import { ChevronRight } from 'lucide-react'
import { NavLink, useLocation } from 'react-router-dom'
import Image from '../image'
import { menuList, type IMenuItem } from './constants'

const menuLinkItemObj = {
  sub: {
    MenuItem: SidebarMenuSubItem,
    MenuButton: SidebarMenuSubButton
  },
  normal: {
    MenuItem: SidebarMenuItem,
    MenuButton: SidebarMenuButton
  }
}

// 跳转item
const LinkItem: React.FC<{ item: IMenuItem; type: 'normal' | 'sub' }> = ({ item, type }) => {
  const { MenuButton, MenuItem } = menuLinkItemObj[type]
  const { pathname } = useLocation()

  return (
    <MenuItem key={item.path}>
      <MenuButton asChild isActive={pathname === item.path}>
        <NavLink to={item.path}>
          {!!item.icon && <item.icon />}
          <span>{item.title}</span>
        </NavLink>
      </MenuButton>
    </MenuItem>
  )
}

const HasChildrenItem: React.FC<{ item: IMenuItem }> = ({ item }) => {
  const { pathname } = useLocation()
  return (
    <Collapsible key={item.title} asChild defaultOpen={startsWith(pathname, item.path)} className="group/collapsible">
      <SidebarMenuItem>
        <CollapsibleTrigger asChild>
          <SidebarMenuButton tooltip={item.title}>
            {item.icon && <item.icon />}
            <span>{item.title}</span>
            <ChevronRight className="ml-auto transition-transform duration-200 group-data-[state=open]/collapsible:rotate-90" />
          </SidebarMenuButton>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <SidebarMenuSub>
            {item.children?.map((subItem: any) => <LinkItem type="sub" key={subItem.title} item={subItem} />)}
          </SidebarMenuSub>
        </CollapsibleContent>
      </SidebarMenuItem>
    </Collapsible>
  )
}

const SideBarList: React.FC<{ sidebarList: IMenuItem[] }> = ({ sidebarList }) => {
  if (!sidebarList?.length) {
    return null
  }
  return sidebarList.map((item) => {
    if (item.children?.length) {
      // 有子菜单
      return <HasChildrenItem key={item.path} item={item} />
    }
    return <LinkItem type="normal" key={item.path} item={item} />
  })
}

export function AppSidebar() {
  return (
    <Sidebar>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="py-2 h-10">
            <Image width={150} src="//res.17track.net/global-v2/imgs/logo/svg/full_owt_296x48.svg" />
          </SidebarGroupLabel>
          <SidebarGroupContent className="pt-2">
            <SidebarMenu>
              <SideBarList sidebarList={menuList} />
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  )
}
