const ErrorComponent = () => <div className="text-center">请求出现了问题</div>

export default ErrorComponent
