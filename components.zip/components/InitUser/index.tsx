import { initCrisp } from '@/src/utils/crisp'
import { initGtagGA, sendGaEvent } from '@/src/utils/ga4'
import { I18n } from '@src/components/I18nCommon/i18n'

import { useUserStore } from '@src/store/userStore'
import { useEffect } from 'react'

window.sendGaEvent = sendGaEvent

function InitUser({ children }: any) {
  const { fetchUser, userInfo } = useUserStore()

  useEffect(() => {
    fetchUser()
  }, [fetchUser])

  useEffect(() => {
    if (userInfo.FEmail) {
      let gtagId = ''
      //根据当前环境切换ga4统计容器
      if (process.env.NODE_ENV === 'production') {
        gtagId = 'G-YR82RV30WE' // api站GA4 ID
      } else {
        gtagId = 'G-V4LE7Z0DDV'
      }
      initCrisp(userInfo.FEmail)
      initGtagGA(gtagId, { user_paid_type: 0 })
    }
  }, [userInfo.FEmail])

  return <>{userInfo && userInfo.gid && <I18n locale={userInfo.FLanguage}>{children}</I18n>}</>
}

export default InitUser
