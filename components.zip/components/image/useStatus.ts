import { useEffect, useRef, useState } from 'react'

interface Props {
  src: string
  isCustomPlaceholder: boolean
  fallback: string | undefined | null
}

type Status = 'error' | 'loading' | 'normal'

const useStatus = ({ src, isCustomPlaceholder, fallback }: Props) => {
  const [status, setStatus] = useState<Status>(isCustomPlaceholder ? 'loading' : 'normal')
  const loadedRef = useRef(false)

  const loadError = status === 'error'

  // useEffect(() => {
  //   // src改变，不会置为 error
  //   let isCurrentSrc = true
  //   validateImage(src).then((isValid) => {
  //     if (isCurrentSrc && !isValid) {
  //       setStatus('error')
  //     }
  //   })

  //   return () => {
  //     isCurrentSrc = false
  //   }
  // }, [src])

  useEffect(() => {
    if (isCustomPlaceholder && !loadedRef.current) {
      // 未加载完成
      return setStatus('loading')
    }
    setStatus('normal')
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [src])

  const getImageRef = (imgEle?: HTMLImageElement) => {
    console.log('getImageRef run')
    loadedRef.current = false
    // complete 表示 图像是否已经加载完毕, naturalHeight/naturalWidth 指示图像的固有高度（以 CSS 像素为单位）。这是在没有为图像建立约束或特定值时自然绘制图像的高度
    if (status === 'loading' && imgEle?.complete && (imgEle.naturalHeight || imgEle.naturalWidth)) {
      loadedRef.current = true
    }
  }

  const onLoad = () => {
    setStatus('normal')
  }

  const onError = () => {
    setStatus('error')
  }

  // TODO: https://github.com/react-component/image/blob/master/src/hooks/useStatus.ts
  const srcAndOnEvent = loadError && fallback ? { src: fallback } : { src, onLoad, onError }

  return {
    getImageRef,
    status,
    ...srcAndOnEvent
  }
}

export default useStatus
