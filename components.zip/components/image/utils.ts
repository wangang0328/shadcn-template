/**
 * 加载 img 是否成功
 */
export const validateImage = (src: string) =>
  new Promise<boolean>((resolve) => {
    const ele = document.createElement('img')
    ele.onerror = () => {
      resolve(false)
    }
    ele.onload = () => {
      resolve(true)
    }
    ele.src = src
  })
