import React from 'react'

interface State {
  hasError: boolean
}

const ErrorComp = () => <>出错了...</>

export default class ErrorBoundary extends React.Component<{ children: JSX.Element; ErrorComponent?: JSX.Element }> {
  state: State
  constructor(props: any) {
    super(props)
    this.state = { hasError: false }
  }

  static getDerivedStateFromError() {
    return { hasError: true }
  }

  render() {
    if (this.state.hasError) {
      return this.props.ErrorComponent ? this.props.ErrorComponent : <ErrorComp />
    }
    return this.props.children
  }
}
