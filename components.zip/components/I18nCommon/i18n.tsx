import i18nHash from '@/public/locales/i18n-bundle.json'
import { createContext, Fragment, useCallback, useEffect, useMemo, useRef, useState } from 'react'
import initI18n from './initI18n'

export const i18n = initI18n()
export const defaultLanguage = 'en'

export const I18nContext = createContext({})

// default language
i18n.locale(defaultLanguage)

export function I18n({ children, locale = 'en' }: any) {
  const activeLocaleRef = useRef(defaultLanguage)
  const [, setTick] = useState(0)
  const [frontData, setFrontData] = useState({})
  const [i18nLoading, setI18nLoading] = useState(false)
  const i18nWrapper = useMemo(
    () => ({
      activeLocale: activeLocaleRef.current,
      $t: (key: string, lang?: string) => i18n.t(key, lang),
      locale: (l: string, dict: any) => {
        i18n.locale(l)
        activeLocaleRef.current = l
        if (dict) {
          i18n.set(l, dict)
        }
        // force rerender to update view
        setTick((tick) => tick + 1)
      },
      i18nFormat: (str: string, args: Array<any>) => {
        if (!str) return ''
        const splitArr = str.split(/(\{[0-9]?\})/g).filter((item) => item)
        let index = 0
        let hasDom = false
        const actionText = splitArr.map((item) => {
          if (/\{[0-9]?\}/g.test(item)) {
            index += 1
            const i = args[index - 1]
            if (typeof i === 'object') hasDom = true
            return i
          } else {
            return item
          }
        })
        return hasDom ? (
          <>
            {actionText.map((item: any, i: number) => (
              <Fragment key={i}>{item}</Fragment>
            ))}
          </>
        ) : (
          actionText.join('')
        )
        // console.log(splitArr)
        // const substitute = args
        // return str.replace(/\\?{([^{}]+)\}/gm, (match, name) => {
        //   if (match.charAt(0) == '\\') {
        //     return match.slice(1)
        //   }
        //   if (name >= 0 || substitute[name] !== void 0) {
        //     return substitute[name]
        //   }
        //   return ''
        // })
      }
    }),
    []
  )

  // locale更新时更换词条资源
  const fetchLocale = useCallback(async () => {
    setI18nLoading(true)
    const I18NHASH: Record<string, string> = i18nHash as any
    const JsonResponse = await fetch(`/locales/${locale}.${I18NHASH[locale] || 'en'}.json`)
    const V5FrontJson = await JsonResponse.json()
    setFrontData(V5FrontJson)
    i18nWrapper.locale(locale, V5FrontJson)
    setI18nLoading(false)
  }, [i18nWrapper, locale])

  // 懒赋值 - 同时为了更新语言切换后的操作
  useEffect(() => {
    console.log('locale', locale)
    if (locale) {
      fetchLocale()
    }
  }, [fetchLocale, locale])

  return (
    <I18nContext.Provider value={i18nWrapper}>
      {Object.keys(frontData).length > 0 && !i18nLoading ? (
        children
      ) : (
        <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          加载中词条中
        </div>
      )}
    </I18nContext.Provider>
  )
}
