import { Table } from '@tanstack/react-table'
import { isUndefined } from 'lodash-es'
import React from 'react'
import { useTableContext } from '../../TableContext'

interface FilterItemProps {
  id: string
  label: string
  /**
   * 用于下侧回显
   */
  options?: Array<{ label: string; value: string }>
  /**
   * 取value值的key 默认 value
   **/
  valueKey?: string

  /**
   * 监听修改的key，默认 onChange
   */
  onChangeKey?: string
  /**
   * onChange获取值的路径 eg: .a.b.e, 直接取 onChange的值 - '.'
   */
  getValuePath?: string

  /**
   * 默认值
   */
  defaultValue?: any

  /**
   * 触发的时机
   */
  trigger?: 'change' | 'manual'
  [key: string]: any
}

interface InternalFilterItemProps {
  // column: Column<any>
  id: string
  label: string
  /**
   * 取value值的key 默认 value
   **/
  valueKey?: string
  /**
   * 监听修改的key，默认 onChange
   */
  onChangeKey?: string
  /**
   * onChange获取值的路径 eg: .a.b.e, 直接取 onChange的值 - '.'
   */
  getValuePath?: string

  /**
   * 触发的时机
   */
  trigger?: 'change' | 'manual'
  table: Table<any>
  [key: string]: any
}

interface ChildPorps {
  [key: string]: any
}

class InternalFilterItem extends React.Component<InternalFilterItemProps> {
  private isMouted = false

  componentDidMount() {
    this.isMouted = true
    const { table, defaultValue, id } = this.props
    const oldFilters = table.getState().columnFilters
    let founded = false
    const targetFilters = oldFilters.map((item) => {
      if (item.id === id) {
        founded = true
        return {
          id: item.id,
          value: defaultValue
        }
      }
      return item
    })
    if (!founded) {
      targetFilters.push({ id, value: defaultValue })
    }
    // 初始值 undefined
    table.setColumnFilters(targetFilters)
  }

  public reRender = () => {
    if (this.isMouted) {
      this.forceUpdate()
    }
  }

  public getControlled = (props: ChildPorps = {}) => {
    const {
      run,
      id,
      valueKey = 'value',
      onChangeKey = 'onChange',
      getValuePath,
      table,
      trigger = 'change'
    } = this.props

    const { value } = table.getState().columnFilters.find((item) => item.id === id) || {}
    return {
      [valueKey]: value,
      [onChangeKey]: (value: any) => {
        let newValue

        // 获取值的方法
        const pathList = getValuePath?.split('.').filter(Boolean)
        if (pathList) {
          // debugger
          newValue = pathList.reduce((acc, key) => acc[key], value)
        } else {
          // 取值
          newValue = isUndefined(value.target?.value) ? undefined : value.target.value
          if (isUndefined(value.target) && !isUndefined(value)) {
            newValue = value
          }
        }
        // column.setFilterValue(newValue)
        const oldFilters = table.getState().columnFilters
        let founded = false
        const targetFilters = oldFilters.map((item) => {
          if (item.id === id) {
            founded = true
            return {
              id: item.id,
              value: newValue
            }
          }
          return item
        })
        if (!founded) {
          targetFilters.push({ id, value: newValue })
        }
        table.setColumnFilters(targetFilters)
        console.log('---------', targetFilters, table.getState())
        if (trigger === 'change') {
          run()
        }
      },
      ...props
    }
  }

  public render() {
    const { children } = this.props
    if (!children) {
      // 如果没有children或者没有name，那么就没必要受控
      return children
    }
    return React.cloneElement(children, this.getControlled(children.props))
  }
}

const FilterItem: React.FC<FilterItemProps> = ({ id, ...restProps }) => {
  // const { table } = useTableContext()
  const { table, run } = useTableContext()
  console.log('table--------', table)
  if (!table) {
    console.error('use in table')
    return null
  }
  // table?.getFilteredRowModel().rows
  // const column = table.getColumn(id)
  // if (!column) {
  //   console.error('column not found')
  //   return null
  // }
  return <InternalFilterItem run={run} table={table} key={id} id={id} {...restProps} />
}

export default FilterItem
