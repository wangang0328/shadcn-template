import { Button } from '@/src/components/ui/button'
import { Table } from '@tanstack/react-table'
import { X } from 'lucide-react'
import { FC } from 'react'

interface FilterBadgeProps {
  table: Table<any>
  run: any
}

const columnFilters = [
  {
    id: 'aa',
    label: '姓名',
    value: 'aa'
  },
  {
    label: '年龄',
    value: 'dd',
    id: 'dd'
  },
  {
    label: '性别',
    value: 'cc',
    id: 'cc'
  }
]
const FilterBadge: FC<FilterBadgeProps> = ({ table, run }) => {
  const { columnFilters: _aa } = table.getState()
  console.log(_aa)

  const handleClear = (id?: string) => {
    if (id) {
      const targetFilters: any = []
      table.getState().columnFilters.forEach((item) => {
        if (item.id !== id) {
          targetFilters.push(item)
        }
      })
      table.setColumnFilters(targetFilters)
    } else {
      table.resetColumnFilters()
    }
    run()
  }

  return (
    <div className="flex">
      <ul className="flex gap-2 items-center">
        {columnFilters.map(({ id, label, value }) => (
          <li key={id} className="bg-surface-secondary rounded-md flex items-center h-6 flex-none text-body-xs">
            <div className="px-1.5 py-1">
              {label}: {value as string}
            </div>
            <div
              onClick={() => handleClear(id)}
              className="cursor-pointer hover:bg-surface-secondary_hover h-full inline-flex w-6 flex-none items-center justify-center rounded-md"
            >
              <X width={12} height={12} />
            </div>
          </li>
        ))}
        <li>
          <Button onClick={() => handleClear()} variant="link" size="sm" className="p-0 h-auto">
            clear all
          </Button>
        </li>
      </ul>
      {/* <Button variant="link" size="sm">
        clear all
      </Button> */}
    </div>
  )
}

export default FilterBadge
