const NoData = () => <div className="text-center">没有数据</div>

export default NoData
