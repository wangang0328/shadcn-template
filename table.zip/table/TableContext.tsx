import type { Table } from '@tanstack/react-table'
import { createContext, useContext } from 'react'

export const TableContext = createContext<{ table: Table<any> | null; run: Function }>({ table: null, run: () => {} })

export const useTableContext = () => useContext(TableContext)
